#!/usr/bin/env bash
set -euo pipefail
bash scripts/sc_step.sh
