#!/usr/bin/env bash
set -euo pipefail
ROOT="/opt/ats-quant"
cd "$ROOT"

ts() { date -u +%Y%m%dT%H%M%SZ; }
mask() { # 局部打码
  local s="$1"; local n=${#s}
  if (( n <= 8 )); then printf '%s' "$s"; else printf '%s%s%s' "${s:0:4}" "$(printf '%*s' $((n-8)) ''|tr ' ' '*')" "${s: -4}"; fi
}

load_env() { if [ -f ".env" ]; then set -a; . ./.env; set +a; fi; }
tg_text() { load_env; [ -n "${TELEGRAM_BOT_TOKEN:-}" ] && [ -n "${TELEGRAM_CHAT_ID_PRIMARY:-}" ] &&
  curl -sS -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
    -d "chat_id=${TELEGRAM_CHAT_ID_PRIMARY}" --data-urlencode "parse_mode=Markdown" \
    --data-urlencode "text=$1" >/dev/null || true; }
tg_doc() { load_env; local f="$1"; local cap="${2:-}"; [ -f "$f" ] || return 0
  [ -n "${TELEGRAM_BOT_TOKEN:-}" ] && [ -n "${TELEGRAM_CHAT_ID_PRIMARY:-}" ] &&
  curl -sS -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
    -F "chat_id=${TELEGRAM_CHAT_ID_PRIMARY}" -F "caption=${cap}" -F "document=@${f}" >/dev/null || true; }

health() {
  local T=$(ts) OUT="reports/health_${T}.md"
  local HOST=$(hostname) NOW=$(date -u +"%F %T") PWD=$(pwd)

  local BRANCH LAST REMOTES
  BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "-")
  LAST=$(git log -1 --pretty='%h %ad %s' --date=iso 2>/dev/null || echo "-")
  REMOTES=$(git remote -v 2>/dev/null || echo "-")

  local DVER CVER
  DVER=$(docker --version 2>/dev/null || echo "docker N/A")
  CVER=$(docker compose version 2>/dev/null || echo "compose N/A")
  local PS; PS=$(docker ps -a --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}' | sed -n '1,6p' || true)

  load_env
  local EK="${BINANCE_API_KEY:-}" ES="${BINANCE_API_SECRET:-}" TK="${TELEGRAM_BOT_TOKEN:-}"
  local ENV_MASK=$(cat <<E
- HOST_TAG: \`${HOST_TAG:-}\`
- TRADING_ENABLED: \`${TRADING_ENABLED:-}\`   DRY_RUN: \`${DRY_RUN:-}\`
- BINANCE_API_KEY: \`$( [ -n "$EK" ] && echo "$(mask "$EK")" || echo "N/A")\`
- BINANCE_API_SECRET: \`$( [ -n "$ES" ] && echo "$(mask "$ES")" || echo "N/A")\`
- TELEGRAM_BOT_TOKEN: \`$( [ -n "$TK" ] && echo "$(mask "$TK")" || echo "N/A")\`
E
)

  local BIN_HTTP TG_HTTP
  BIN_HTTP=$(curl -s -o /dev/null -w "%{http_code}" https://fapi.binance.com/fapi/v1/ping || echo "000")
  TG_HTTP=$( [ -n "${TELEGRAM_BOT_TOKEN:-}" ] && curl -s -o /dev/null -w "%{http_code}" \
    "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getMe" || echo "000")

  # 日志速览（从容器抓最近1200行）
  docker logs --tail 1200 ats-quant > reports/ats_logs.txt 2>&1 || true
  local SCANS LAST_LINE PLANS ERR E418 E429 E1003
  SCANS=$(grep -c "扫描完成" reports/ats_logs.txt || true)
  LAST_LINE=$(grep "扫描完成" reports/ats_logs.txt | tail -n1 || echo "")
  PLANS=$(grep -c "A+计划" reports/ats_logs.txt || true)
  ERR=$(grep -ci "ERROR\|Traceback\|exception" reports/ats_logs.txt || true)
  E418=$(grep -c " 418 " reports/ats_logs.txt || true)
  E429=$(grep -c " 429 " reports/ats_logs.txt || true)
  E1003=$(grep -c "-1003" reports/ats_logs.txt || true)

  {
    echo "# ATS 健康报告 ${T}"
    echo "- Host: \`${HOST}\`"
    echo "- Time(UTC): \`${NOW}\`"
    echo "- PWD: \`${PWD}\`"
    echo
    echo "## Git"
    echo "- Branch: \`${BRANCH}\`"
    echo "- Last: \`${LAST}\`"
    echo
    echo "Remotes:"
    echo '```'; echo "${REMOTES}"; echo '```'
    echo
    echo "## Docker"
    echo '```'; echo "${DVER}"; echo "${CVER}"; echo; echo "[compose ps]"; echo "${PS}"; echo '```'
    echo
    echo "## .env（打码）"; echo "${ENV_MASK}"; echo
    echo "## 连通性"
    echo "- Binance ping HTTP: \`${BIN_HTTP}\`（期望 200）"
    echo "- Telegram getMe HTTP: \`${TG_HTTP}\`（期望 200）"
    echo
    echo "## 日志速览（容器最近1200行）"
    echo "- 扫描次数: \`${SCANS}\`"
    echo "- 最近扫描: \`${LAST_LINE}\`"
    echo "- 计划条数: \`${PLANS}\`"
    echo "- 错误计数: \`${ERR}\`"
    echo "- 限流: 418=\`${E418}\` 429=\`${E429}\` -1003=\`${E1003}\`"
  } > "${OUT}"

  tg_text "📋 *ATS 健康检查* 已生成：\`${T}\`  \nHost=\`${HOST}\`  Branch=\`${BRANCH}\`"
  tg_doc "${OUT}" "ATS 健康报告 ${T}"
  tg_doc "reports/ats_logs.txt" "ATS 原始日志（最近1200行） ${T}"
  echo "✅ 已发送健康报告与日志到 Telegram：${OUT}"
}

logs() { # logs [n]
  local N="${1:-1200}" T=$(ts)
  docker logs --tail "$N" ats-quant > "reports/ats_logs_${T}.txt" 2>&1 || true
  tg_doc "reports/ats_logs_${T}.txt" "ATS 原始日志（最近${N}行） ${T}"
  echo "✅ 已发送最近${N}行日志到 Telegram"
}

cmd() { # cmd '<SHELL_CMD...>'
  local T=$(ts) OUT="reports/cmd_${T}.txt"
  bash -lc "$*" > "${OUT}" 2>&1 || true
  tg_doc "${OUT}" "ATS 远程命令输出 ${T}"
  echo "✅ 已发送命令输出到 Telegram：$*"
}

repo() {
  local T=$(ts) OUT="reports/repo_${T}.md"
  {
    echo "# 仓库结构快照 ${T}"
    echo '```'
    git --version 2>/dev/null
    echo; echo "[tree -L 2]"
    (command -v tree >/dev/null && tree -L 2 || find . -maxdepth 2 -type d -printf '%p\n') 2>/dev/null
    echo '```'
  } > "${OUT}"
  tg_doc "${OUT}" "ATS 仓库结构 ${T}"
  echo "✅ 已发送仓库结构到 Telegram：${OUT}"
}

case "${1:-help}" in
  health) health ;;
  logs) shift || true; logs "${1:-1200}" ;;
  cmd) shift || true; cmd "$*" ;;
  repo) repo ;;
  *) echo "用法: bash scripts/ats_report.sh {health|logs [N]|cmd '<命令>'|repo}"; exit 0;;
esac
